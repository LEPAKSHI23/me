package com.cg.flp.dao;

import java.util.ArrayList; 




import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.flp.entity.Customer;
import com.cg.flp.entity.Product;
import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;

@Repository
public class Dao implements IDao{
	@PersistenceContext
	private EntityManager entityManager;
	Wish wishlist=new Wish();

	public Integer add(int productId, String emailId) throws FlpException {
		try {
			
			Product p = entityManager.find(Product.class,productId);
			Customer c=entityManager.find(Customer.class,emailId);
			System.out.println(p);
			wishlist.setProduct_Description(p.getProduct_Description());
			wishlist.setProduct_Id(p.getProduct_Id());
			wishlist.setProduct_Name(p.getProduct_Name());
			wishlist.setProduct_Price(p.getProduct_Price());
			wishlist.setCustomer_emailId(c.getEmail_Id());
			entityManager.persist(wishlist);
			/*if(wishlist!=null){
			return 1;}
			else{*/
				return 1;
			
		
			
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
		

	}
	
	
	public ArrayList<Wish> showall(String emailId) throws FlpException {
		ArrayList<Wish> list = new ArrayList<>();
		String jpql = "Select product from CustomerEntity product where product.customeremailId=?1";
		TypedQuery<Wish> query = (TypedQuery<Wish>) entityManager.createQuery(jpql, Wish.class);
		query.setParameter(1,emailId );
		list = (ArrayList<Wish>) query.getResultList();
		return list;
	}

	public int delete(int id) throws FlpException {
		try {
			Wish user = (Wish) entityManager.find(Wish.class, id);
			entityManager.remove(user);
			return 1;
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
	}
}
