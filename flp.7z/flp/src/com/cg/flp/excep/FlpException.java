package com.cg.flp.excep;

public class FlpException  extends Exception{
	private String message;

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "FlpException [message=" + message + "]";
	}

	public FlpException() {
		}

	public FlpException(String message) {
		super();
		this.message = message;
	}

}
