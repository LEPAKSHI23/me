package com.cg.flp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="wishlist")
public class Wish  {
	@Id
	private String product_Name;
	
	private String product_Description ;
	private Double product_Price;	
	private Integer product_Id;	
	private String customer_emailId;
	
	
	
	public String getProduct_Name() {
		return product_Name;
	}



	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}



	public String getProduct_Description() {
		return product_Description;
	}



	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}



	public Double getProduct_Price() {
		return product_Price;
	}



	public void setProduct_Price(Double product_Price) {
		this.product_Price = product_Price;
	}



	public Integer getProduct_Id() {
		return product_Id;
	}



	public void setProduct_Id(Integer product_Id) {
		this.product_Id = product_Id;
	}



	public String getCustomer_emailId() {
		return customer_emailId;
	}



	public void setCustomer_emailId(String customer_emailId) {
		this.customer_emailId = customer_emailId;
	}



	@Override
	public String toString() {
		return "Wishlist [productName=" + product_Name
				+ ", product_Description=" + product_Description
				+ ", product_Price=" + product_Price + ", product_Id="
				+ product_Id + ", customer_emailId=" + customer_emailId + "]";
	}



	
	
	
	
	
	
	
	
}
