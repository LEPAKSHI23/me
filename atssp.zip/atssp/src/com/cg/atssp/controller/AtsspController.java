package com.cg.atssp.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.enterprise.inject.Model;
import javax.xml.crypto.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.atssp.dto.TimeSheet;
import com.cg.atssp.service.IAtsspService;
@Controller
	public class AtsspController {

@Autowired
IAtsspService atsspervice;
@RequestMapping(value="/home",method=RequestMethod.GET)
public String home(){
		return "home";
		}
	
		@RequestMapping(value="timesheet")
		public ModelAndView timesheet(@ModelAttribute("my") TimeSheet ts, Map<String,Object> map){
			List<String> myList=new ArrayList<>();
			myList.add("--Select--");
			myList.add("DATA_ENTRY");
			myList.add("ACCOUNTS_TALLY");
			myList.add("LEDGER_POSTINGS");
			myList.add("+8");
			myList.add("RETURNS_FILING");
			map.put("activity", myList);
			Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
		    String strDate= formatter.format(date);  
		    System.out.println(strDate);  
				return new ModelAndView("timesheet", "date", strDate);
		}
	
	
	
	@RequestMapping(value="success",method=RequestMethod.POST)
	public ModelAndView timesheetupload(@ModelAttribute("my") TimeSheet ts){ 
		ts.setTsDate();
		Integer id=atsspervice.TimeSheetUpload(ts);
		
		
		return new ModelAndView("success", "data", id);
	}
}

