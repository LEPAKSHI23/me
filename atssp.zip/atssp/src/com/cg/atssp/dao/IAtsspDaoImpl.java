package com.cg.atssp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.atssp.dto.TimeSheet;


@Repository
@Transactional
public class IAtsspDaoImpl implements IAtsspDao {

	

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Integer timeshetupload(TimeSheet ts) {
		em.persist(ts);
		em.flush();
		
		
		return ts.getTsId();
	}

}
