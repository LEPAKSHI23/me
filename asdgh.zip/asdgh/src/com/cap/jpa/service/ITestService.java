package com.cap.jpa.service;

import com.cap.jpa.model.TestBean;

public interface ITestService {
TestBean findqueryID(Integer queryID);



boolean textarea(Integer queryID, String textarea);
}
