/**
 * 
 */
/**
 * @author lsriniva
 *
 */
package com.capgemini.trg.conf;