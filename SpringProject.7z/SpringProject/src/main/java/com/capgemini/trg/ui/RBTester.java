package com.capgemini.trg.ui;

import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class RBTester {
	  public static void main( String[] args )    {
	    	/*@SuppressWarnings("deprecation")
	       XmlBeanFactory beanFactory =new XmlBeanFactory(new ClassPathResource("spring.xml"));*/
	    
	    ApplicationContext context =new ClassPathXmlApplicationContext("spring.xml");
	    System.out.println("===========================");
	Locale currentLocale=Locale.getDefault();
	System.out.println(currentLocale.getLanguage());
	System.out.println(currentLocale.getCountry());
	System.out.println("========================");
	String message=context.getMessage("greetings",null, null);
	System.out.println(message);
	System.out.println("========================");
	
	 message=context.getMessage("greetings",null, Locale.FRANCE);
	System.out.println(message);
	System.out.println("========================");
	Locale frenchLocale = new Locale ("fr","FR");
	 message=context.getMessage("greetings",null, frenchLocale);
	System.out.println(message);
	System.out.println("================================");
	ResourceBundle bundle= ResourceBundle.getBundle("message_fr_FR", frenchLocale);
	Enumeration enumeration=bundle.getKeys();
	while(enumeration.hasMoreElements())
	{
		String key=(String)enumeration.nextElement();
		System.out.println(key+"="+bundle.getObject(key));
	}
	
	
	((AbstractApplicationContext) context).registerShutdownHook();

	
	  }
}
