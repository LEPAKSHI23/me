package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.capgemini.trg.model.HelloIndia;

public class HelloIndiaDemo {

	public HelloIndiaDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring_ann.xml");
	/*HelloIndia obj1=(HelloIndia)context.getBean("helloIndiaBean");
	System.out.println(obj1.getMessage().getMessage1());
	System.out.println(obj1.getMessage().getMessage2());
	System.out.println(obj1.getMessage().getMessage3());*/
		HelloIndia obj1=(HelloIndia)context.getBean("helloIndia");
		System.out.println(obj1.getMessage().getMessage1());
		System.out.println(obj1.getMessage().getMessage2());
		System.out.println(obj1.getMessage().getMessage3());
	
		((AbstractApplicationContext) context).registerShutdownHook();
}

}
