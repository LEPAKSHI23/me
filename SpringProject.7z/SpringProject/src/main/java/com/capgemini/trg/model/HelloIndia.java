package com.capgemini.trg.model;

import javax.annotation.Resource;

/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;*/
import org.springframework.stereotype.Component;

@Component
public class HelloIndia {
//	@Autowired
	
	/*@Autowired(required=false)
	@Qualifier(value="messageBean")*/
	
	@Resource(name="messageBean")
	 private Message message;

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	 
	
	 

}
