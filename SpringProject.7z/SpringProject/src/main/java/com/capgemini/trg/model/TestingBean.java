package com.capgemini.trg.model;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class TestingBean  implements  InitializingBean,DisposableBean {

	public TestingBean() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Initializing b4 bean instance");
		
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("destroy after  bean instance");
		
	}

}
