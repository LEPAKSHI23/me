package com.capgemini.trg.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.trg.model.HelloWorld;

@Configuration
public class HelloWorldConfiguration {

	public HelloWorldConfiguration() {
		// TODO Auto-generated constructor stub
	}
	//default id method name
	//helloworld

	@Bean(name="hello")
	public HelloWorld helloWorld()
	{return new HelloWorld();}
}
