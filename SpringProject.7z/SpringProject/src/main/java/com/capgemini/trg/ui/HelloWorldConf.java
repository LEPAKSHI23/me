package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.trg.conf.HelloWorldConfiguration;
import com.capgemini.trg.model.HelloWorld;

public class HelloWorldConf {

	public HelloWorldConf() {
		
	}

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(HelloWorldConfiguration.class);
		/*HelloWorld obj1=(HelloWorld)context.getBean("helloWorld");
		System.out.println(obj1.getMessage());*/
		HelloWorld obj1=(HelloWorld)context.getBean("hello");
		System.out.println(obj1.getMessage());
	}

}
