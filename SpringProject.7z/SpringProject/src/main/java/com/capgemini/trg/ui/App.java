package com.capgemini.trg.ui;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.Country;
import com.capgemini.trg.model.CurrencyConverter;
import com.capgemini.trg.model.HelloWorld;


public class App {
    public static void main( String[] args )    {
    	/*@SuppressWarnings("deprecation")
       XmlBeanFactory beanFactory =new XmlBeanFactory(new ClassPathResource("spring.xml"));*/
    
    ApplicationContext context =new ClassPathXmlApplicationContext("spring.xml");
    
    HelloWorld object = (HelloWorld)context.getBean("helloWorldBean");
    
    System.out.println(object.getMessage());
    CurrencyConverter converter1=(CurrencyConverter)context.getBean("converterBean1");
    System.out.println("$100=rs."+converter1.dollarToRupee(100.0));
    
    CurrencyConverter converter2=(CurrencyConverter)context.getBean("converterBean2");
    System.out.println("$100=rs."+converter2.dollarToRupee(100.0));
    Country country = (Country)context.getBean("countryBean");
    List<String> countryList= country.getCountryList();
   Set<String> countrySet= country.getCountrySet();
   Map<String,String> countryMap= country.getCountryMap();
   Iterator <String>it =countryList.iterator();
   while(it.hasNext())
	   System.out.println(it.next());
   System.out.println("==================================================");
   countryList.stream().forEach(System.out::println);
   System.out.println("==================================================");
  /* countryList.stream().forEach((s)->Systom.out.println(s));*/
   Iterator <String>it1 =countryList.iterator();
   while(it1.hasNext())
	   System.out.println(it1.next());
   System.out.println("==================================================");
   
   for(Map.Entry<String, String> m:countryMap.entrySet())
	   System.out.println(m.getKey()+" "+m.getValue());
   
   
   
   
    ((AbstractApplicationContext)context).registerShutdownHook();
    }
}
