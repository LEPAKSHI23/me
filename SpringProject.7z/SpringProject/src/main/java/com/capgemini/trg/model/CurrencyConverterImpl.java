package com.capgemini.trg.model;

public class CurrencyConverterImpl implements CurrencyConverter{
	private double exchange;
	
	public CurrencyConverterImpl(){
		
	}


	public double getExchange() {
		return exchange;
	}

	public void setExchange(double exchange) {
		this.exchange = exchange;
	}

	public CurrencyConverterImpl(double exchange) {
		super();
		this.exchange = exchange;
	}

	@Override
	public double dollarToRupee(double dollars) {
		// TODO Auto-generated method stub
		return dollars*this.exchange;
	}

}
