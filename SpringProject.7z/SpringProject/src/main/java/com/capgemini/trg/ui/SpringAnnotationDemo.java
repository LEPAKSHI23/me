package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.HelloWorld;

public class SpringAnnotationDemo {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext context =new ClassPathXmlApplicationContext("spring_ann.xml");
		 HelloWorld obj=(HelloWorld) context.getBean("helloWorld");
		 System.out.println(obj.getMessage());
		 
		 ((AbstractApplicationContext) context).registerShutdownHook();

	}

}
