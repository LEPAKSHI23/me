package com.capgemini.mps.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mps.dto.Mobile;
import com.capgemini.mps.exception.MobilePurchaseException;
import com.capgemini.mps.utility.MySqlConnection;

public class MobileDaoImp implements IMobileDao {

	@Override
	public Integer addNewMobile(Mobile mobile) throws MobilePurchaseException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try{
			connection =MySqlConnection.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_MOBILE);
			//preparedStatement.setLong(1,mobile.getMobiles_id());
			preparedStatement.setString(1, mobile.getName());
			preparedStatement.setDouble(2, mobile.getMobile_price());
			preparedStatement.setInt(3, mobile.getQuantity());
			int n = preparedStatement.executeUpdate();
			return n;
		}catch(SQLException e){

			throw new MobilePurchaseException("unable to add new mobile"+" "+e.getMessage());

		}catch(Exception e){
			throw new MobilePurchaseException(e.getMessage());

		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block

			}
		}

	}

	@Override
	public Integer deleteMobile(Long mobiles_id) throws MobilePurchaseException {
		try(
				Connection connection=MySqlConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DELETE_MOBILE)
				)
				{
			preparedStatement.setLong(1,mobiles_id);
			int n=preparedStatement.executeUpdate();
			return n;
				}catch(SQLException e)
		{
					e.printStackTrace();
					throw new MobilePurchaseException("Unable to delete mobile details.\n"+e.getMessage());
		}catch(IOException e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());

		}

	}

	@Override
	public Mobile getMobileDetails(Long mobiles_id) throws MobilePurchaseException {
	try
	(
	Connection connection=MySqlConnection.getConnection();
	CallableStatement callable=connection.prepareCall(QueryMapper.GET_MOBILE_DETAILS);
	)
	{	
		callable.registerOutParameter(2,java.sql.Types.VARCHAR);
		callable.registerOutParameter(3,java.sql.Types.DOUBLE);
		callable.registerOutParameter(4,java.sql.Types.INTEGER);
		callable.setLong(1,mobiles_id);
		callable.executeQuery();
		Mobile mobile=new Mobile();
		mobile.setMobiles_id(mobiles_id);
		populateMobile(mobile,callable);
		return mobile;
	}catch(SQLException e)
	{
				e.printStackTrace();
				throw new MobilePurchaseException("Unable to get mobile details.\n"+e.getMessage());
	}catch(IOException e)
	{
		e.printStackTrace();
		throw new MobilePurchaseException(e.getMessage());

	}
	}

	private void populateMobile(Mobile mobile, CallableStatement callable) throws SQLException {
		mobile.setName(callable.getString(2));
		mobile.setMobile_price(callable.getDouble(3));
		mobile.setQuantity(callable.getInt(4));
		
	}

	@Override
	
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException {
		try(
				Connection connection=MySqlConnection.getConnection();
				Statement statement=connection.createStatement();
				)
				{
			ResultSet resultSet=statement.executeQuery(QueryMapper.SELECT_ALL_MOBILE);
			List<Mobile> mobileList=new ArrayList<>();
			while(resultSet.next()){
				Mobile mobile=new Mobile();
				populateMobile(resultSet, mobile);
				mobileList.add(mobile);
			}
			return mobileList;
				}catch(SQLException e)
		{
					e.printStackTrace();
					throw new MobilePurchaseException(e.getMessage());
		}catch(IOException e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());
		}
	}

	private void populateMobile(ResultSet resultSet, Mobile mobile)
			throws SQLException {
		mobile.setMobiles_id(resultSet.getLong("mobiles_id"));
		mobile.setName(resultSet.getString("name"));
		mobile.setMobile_price(resultSet.getDouble("mobile_price"));
		mobile.setQuantity(resultSet.getInt("quantity"));
	}

	@Override
	public Integer updateMobilePrice(Long mobiles_id, Double newPrice)throws MobilePurchaseException {
		try(
				Connection connection=MySqlConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_MOBILE);
				)
				{
			preparedStatement.setDouble(1,newPrice);
			preparedStatement.setLong(2,mobiles_id);

			int n=preparedStatement.executeUpdate();
			return n;
				}catch(SQLException e)
		{
					e.printStackTrace();
					throw new MobilePurchaseException("Unable to update mobile details.\n"+e.getMessage());
		}catch(IOException e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());

		}

	}

	@Override
	public Double getMobilePrice(Long mobiles_id)throws MobilePurchaseException {
	
		try
		(
		Connection connection=MySqlConnection.getConnection();
		CallableStatement callable=connection.prepareCall(QueryMapper.GET_MOBILE_PRICE);
		)
		{	
			callable.registerOutParameter(1,java.sql.Types.DOUBLE);
			callable.setLong(2,mobiles_id);
			callable.executeQuery();
			Double mobile_price=callable.getDouble(1);
			return mobile_price;
		}catch(SQLException e)
		{
					e.printStackTrace();
					throw new MobilePurchaseException("Unable to get mobile price.\n"+e.getMessage());
		}catch(IOException e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());

		}
		}

		

}
