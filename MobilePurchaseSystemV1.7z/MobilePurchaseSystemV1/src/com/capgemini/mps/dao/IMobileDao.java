package com.capgemini.mps.dao;

import java.util.List;

import com.capgemini.mps.dto.Mobile;
import com.capgemini.mps.exception.MobilePurchaseException;

public interface IMobileDao {

	public abstract Integer addNewMobile(Mobile mobile) throws MobilePurchaseException ;
	public abstract Integer deleteMobile(Long mobiles_id) throws MobilePurchaseException ;
	public abstract Mobile getMobileDetails(Long mobiles_id)throws MobilePurchaseException   ;
	public abstract List<Mobile> getAllMobileDetails() throws MobilePurchaseException ;
	public abstract Integer updateMobilePrice(Long mobiles_id,Double newPrice)throws MobilePurchaseException;
	public abstract Double getMobilePrice(Long mobiles_id)throws MobilePurchaseException;
}
