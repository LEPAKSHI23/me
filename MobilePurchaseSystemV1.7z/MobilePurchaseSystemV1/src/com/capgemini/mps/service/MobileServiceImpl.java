package com.capgemini.mps.service;

import java.util.List;

import com.capgemini.mps.dao.IMobileDao;
import com.capgemini.mps.dao.MobileDaoImp;
import com.capgemini.mps.dto.Mobile;
import com.capgemini.mps.exception.MobilePurchaseException;

public class MobileServiceImpl implements IMobileService{
	private IMobileDao mobileDao=new MobileDaoImp();
	@Override
	public Integer addNewMobile(Mobile mobile) throws MobilePurchaseException {
		// TODO validate mobile details
		return mobileDao.addNewMobile(mobile);
	}


	@Override
	public Mobile getMobileDetails(Long mobiles_id) throws MobilePurchaseException
	{
		// TODO Auto-generated method stub
		return mobileDao.getMobileDetails(mobiles_id);
	}

	@Override
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException {

		return mobileDao.getAllMobileDetails();
	}


	@Override
	public Integer deleteMobile(long mobiles_id) throws MobilePurchaseException {


		return mobileDao.deleteMobile(mobiles_id);
	}


	@Override
	public Integer updateMobilePrice(Long mobiles_id, Double newPrice)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDao.updateMobilePrice(mobiles_id, newPrice);
	}


	@Override
	public Double getMobilePrice(long mobiles_id) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDao.getMobilePrice(mobiles_id);
	}
}




