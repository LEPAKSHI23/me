package com.capgemini.mps.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MySqlConnection {

	
	public static Properties properties = null;
	public static Connection connection = null;
		
	private Properties loadProperties() throws IOException {
		if (properties == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);
			inputStream.close();
			return newProps;
		} else {
			return properties;
		}
	}
	public static Connection getConnection() throws IOException{
		properties = new MySqlConnection().loadProperties();
		
			String url = properties.getProperty("url");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");
			
			try {
				connection = DriverManager.getConnection(url,username,password);
				return connection;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}return null;
		}
		
		
	}

