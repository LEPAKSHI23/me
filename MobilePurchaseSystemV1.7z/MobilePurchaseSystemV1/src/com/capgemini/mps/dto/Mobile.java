package com.capgemini.mps.dto;

public class Mobile {
	
	private  Long mobiles_id;
	private String name;
	private double mobile_price;
	private Integer quantity;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Long getMobiles_id() {
		return mobiles_id;
	}
	public void setMobiles_id(Long mobiles_id) {
		this.mobiles_id = mobiles_id;
	}
	public double getMobile_price() {
		return mobile_price;
	}
	public void setMobile_price(double mobile_price) {
		this.mobile_price = mobile_price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobiles_id=" + mobiles_id + ", name=" + name
				+ ", mobile_price=" + mobile_price + ", quantity=" + quantity
				+ "]";
	}
	
	

}
