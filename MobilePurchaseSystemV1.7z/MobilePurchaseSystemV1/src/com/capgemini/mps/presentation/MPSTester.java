package com.capgemini.mps.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.mps.dto.Mobile;
import com.capgemini.mps.exception.MobilePurchaseException;
import com.capgemini.mps.service.IMobileService;
import com.capgemini.mps.service.MobileServiceImpl;



public class MPSTester {
	private static Scanner scanner=new Scanner(System.in);
	Mobile mobile=new Mobile();
	private static IMobileService mobileService=new MobileServiceImpl();

	public static void main(String[] args) throws MobilePurchaseException {		
		while (true) {
			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Mobile Purchase System ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Mobile ");
			System.out.println("2.Update Mobile");
			System.out.println("3.Retrive All Mobiles");
			System.out.println("4.Delete Mobile");
			System.out.println("5.Purchase Mobile");
			System.out.println("6.Get Mobile Details");
			System.out.println("7.Get mobile price");
			System.out.println("8.EXIT");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			
			
			
			
			
			// accept option
			
			try {
				int option = scanner.nextInt();
				switch (option) 
				 {
				case 1:
					//TODO
					Mobile mobile=new Mobile();
					getMobileDetails(mobile);
					int n=0;
					try
					{
						n=addNewMobile(mobile);
					}catch(MobilePurchaseException e)
					{
						e.getMessage();
					}
					break;
				case 2: 
					System.out.println("Enter mobileID");
					long mobiles_id=scanner.nextLong();
					System.out.println("\n Enter new Price:");
					Double newPrice=scanner.nextDouble();
					int result;
					try {
						result = updateMobilePrice(mobiles_id,newPrice);
						System.out.println(result);
					} catch (MobilePurchaseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					break;
				case 3:
					List<Mobile> mobileList2= getAllMobileDetails();
					showMobiles(mobileList2);
					break;
				case 4:
					System.out.println("Enter mobileId: ");
					mobiles_id=scanner.nextLong();
					int status=deleteMobile(mobiles_id);
					System.out.println(status);
					break;
					/*case 5: 
					  System.out.println("Enter customer name(begin with uppercase and name cannot exceed 20 characters): ");
					  String name=scanner.nextLine();					 
					  System.out.println("Enter EmailId: ");
					  String emailId= scanner.nextLine();
					  scanner.nextLine();//clear KBD buffer
					  System.out.println("Enter 10-digit phone number");
					  Long phoneNumber=scanner.nextLong();
					  CustomerValidator validator=new CustomerValidator();
					  if(validator.isValidCustomerName(name)) {
						  if(validator.isValidEmail(emailId)) {
							  if(validator.isValidPhoneNumber(phoneNumber)) {
								  PurchaseDetails purchaseDetails=
										  	new PurchaseDetails();
								  purchaseDetails.setCustomerName(name);
								  purchaseDetails.setEmailId(emailId);
								  purchaseDetails.setPhoneNumber(phoneNumber);
								  System.out.println("Enter mobile Id: ");
								  Integer mid=scanner.nextInt();
								  try {
									if(mobileService.isValidMobileId(mid)) {
										  purchaseDetails.setMobileId(mid);
										  //TODO
									}else {
										System.out.println("Enter valid mobileId");  
									}
								} catch (MobilePurchaseException e) {									
									  System.out.println(e.getMessage());
								}
							  }else {
								  System.out.println("Enter valid phone number");
							  }
						  }else {
							  System.out.println("Enter valid emailId");
						  }
					  }else {
						  System.out.println("Enter valid customer name");
					  }
					  break;*/
				case 6:
					System.out.println("Enter Mobileid");
					mobiles_id=scanner.nextLong();
					Mobile m=getMobDetails(mobiles_id);
					System.out.println(m);
					break;
				case 7:
					System.out.println("Enter mobileID");
					mobiles_id=scanner.nextLong();
					Double price=getMobilePrice(mobiles_id);
					System.out.println("Price="+price);
					
					break;
				case 8:
					System.out.print("Exit Mobile Purchase System");
					System.exit(0);					
				default:
					System.out.println("Enter a valid option[1-6]");
				}// end of switch
			}catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}

	
private static Double getMobilePrice(long mobiles_id) throws MobilePurchaseException {
		
		return mobileService.getMobilePrice(mobiles_id);
	}


	// for case 6
	private static Mobile getMobDetails(long mobiles_id) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		try {
			return mobileService.getMobileDetails(mobiles_id);
		} catch (MobilePurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}



	private static int updateMobilePrice(Long mobiles_id, Double newPrice) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileService.updateMobilePrice(mobiles_id, newPrice);
	}

	private static int addNewMobile(Mobile mobile)throws  MobilePurchaseException{
		// TODO Auto-generated method stub
		return mobileService.addNewMobile(mobile);
	}
	//for case 1
	private static void getMobileDetails(Mobile mobile) {


		System.out.println("\n Enter mobile price");
		mobile.setMobile_price(scanner.nextDouble());
		scanner.nextLine();
		System.out.println("\n Enter quantity");
		mobile.setQuantity(scanner.nextInt());
		scanner.nextLine();
		System.out.println("Enter mobile brand name");
		mobile.setName(scanner.nextLine());
	}




	private static Integer deleteMobile(long mobiles_id) {
		try {
			int status=mobileService.deleteMobile(mobiles_id);
			return status;
		} catch (MobilePurchaseException e) {
			//Log to file
			System.out.println(e.getMessage());
		}
		return null;
	}

	/*private static List<Mobile> getMobilesPriceRange(double lowPrice, double highPrice) {
		try {
			return mobileService.getMobilesPriceRange(lowPrice, highPrice);
		} catch (MobilePurchaseException e) {	
			//Log to file
			System.out.println(e.getMessage());
		}
		return null;
	}*/

	private static void showMobiles(List<Mobile> mobileList) {
		Iterator<Mobile> iterator=mobileList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}

	private static List<Mobile> getAllMobileDetails() {
		List<Mobile> mobileList;
		try {
			mobileList = mobileService.getAllMobileDetails();
			return mobileList; 
		} catch (MobilePurchaseException e) {	
			//log to file
			System.out.println(e.getMessage());
		}
		return null;
	}


}


