package com.capgemini.bankapplication.model;

import org.springframework.stereotype.Component;

@Component
public class Customer {

	private long accountNumber;
	private String panNumber;
	private String cname;
	private String phoneNumber;
	private String adharNumber;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Customer [accountNumber=" + accountNumber + ", panNumber=" + panNumber + ", cname=" + cname
				+ ", phoneNumber=" + phoneNumber + ", adharNumber=" + adharNumber + "]";
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}


}
