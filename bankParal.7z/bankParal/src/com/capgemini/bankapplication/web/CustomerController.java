package com.capgemini.bankapplication.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.bankapplication.bean.Customer;
import com.capgemini.bankapplication.exception.BankException;
import com.capgemini.bankapplication.model.User;
import com.capgemini.bankapplication.service.ICustomerService;
import com.deloitte.trg.service.CustomerException;
import com.deloitte.trg.utility.AppConfig;


@Controller
@RequestMapping(value="/cust")
public class CustomerController {
	long accnum=0;
	String pin;
	@Autowired
	private ICustomerService customerService;
	
	
	@RequestMapping(value="/cmenu")
	public String getCustomerMenu() {
		return "customer_menu";
	}
	
	@RequestMapping(value="prereg" ,method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Customer customer=new Customer();
		return new ModelAndView("registation","customer",customer);
	}

	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="customer")Customer customer) {
		//System.out.println(customer.getCustomerName());
		try {
			String status=Long.toString(customerService.addCustomer(customer));
			return new ModelAndView("cust_status","message",status);
		} catch (BankException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView login(@RequestParam (value="userId") Long acc,@RequestParam(value="password") String password)){  
		accnum=acc;
		pin=password;
		return new;
	}
	
	@RequestMapping(value="/verify", method=RequestMethod.POST)
	
	public String doLogin( @Valid @ModelAttribute("user") User user,
			BindingResult result, HttpServletRequest request, Model model){
	
		try {
			if(result.hasErrors()) {
				List<Object> errorList=result.getAllErrors();
				System.out.println(errorList);
				return "login";
			}else {
				if(isValidCredential(user)) {
					HttpSession session= request.getSession();
					session.setAttribute("userid", user.getUserId());
					return "service";
				}else{
					model.addAttribute("message","Invalid Credentials");
					return "status";
				}
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		model.addAttribute("status","Invalid Credentials");
		return "statuslog";
	}

	private boolean isValidCredential(User user) {
		if("admin".equals(user.getUserId()) && "admin@123".equals(user.getPassword())) {
			return true;
		}
		return false;
	}
	
	
	
	
	

	
	
	
/*	@RequestMapping(value="/allc", method=RequestMethod.GET)
	public ModelAndView getAllCustomerDetails() {
		try {
			List<Customer> customerList=customerService.getAllCustomerDetails();
			if(customerList.size()!=0) {				
				return new ModelAndView("all_customers","customerList",customerList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
		}catch(BankException e) {
			//e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	*/
	
	@RequestMapping(value="/preeditc", method=RequestMethod.GET)
	public ModelAndView preUpdateCustomer(@RequestParam(value="customerid") String customerid) {
		try {
			int id=Integer.parseInt(customerid);
			Customer customer=customerService.getCustomerById(id);
			return new ModelAndView("update_customer","customer",customer);
		}catch(BankException e) {
			return new ModelAndView("status","message",e.getMessage());
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="/posteditc", method=RequestMethod.POST)
	public ModelAndView postUpdateCustomer(@ModelAttribute(value="customer") Customer customer) {
		try {
			//System.out.println(customer.getCustomerName());
			int n=customerService.updateCustomer(customer);
			if(n>0) {
				return new ModelAndView("cust_status","message",AppConfig.PROPERTIES.getProperty("CUSTOMER_UPDATE.SUCCESS"));
			}else {
				return new ModelAndView("cust_status","message",AppConfig.PROPERTIES.getProperty("CUSTOMER_UPDATE.FAIL"));
			}
		}catch(CustomerException e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="/deletec", method=RequestMethod.GET)
	public ModelAndView deleteCustomer(@RequestParam(value="customerid") String customerid) {
		try {
			int id=Integer.parseInt(customerid);
			int n= customerService.deleteCustomer(id);
			if(n>0) {
				return new ModelAndView("cust_status","message","Customer Record Deleted");
			}else {
				return new ModelAndView("cust_status","message","Unable to Delete Customer Record");
			}
		}catch(CustomerException e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping("/status")
	public String goToCustomerMenu() {
		return "customer_menu";
	}
}
