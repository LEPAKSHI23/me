/**
* The class helps creating persistance object 
* and getting its properties
* @author Lepakshi Srinivasan
*/package com.capgemini.bankapplication.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;



@Entity
public class Customer {

	public Customer() {
	}

	public Customer(long accountNumber, String panNumber, String cname,
			String phoneNumber, String adharNumber, double balance,
			String history, String password) {
		super();
		this.accountNumber = accountNumber;
		this.panNumber = panNumber;
		this.cname = cname;
		this.phoneNumber = phoneNumber;
		this.adharNumber = adharNumber;
		this.balance = balance;
		this.history = history;
		this.password = password;
	}

	@Id
	 @GeneratedValue(strategy = GenerationType.SEQUENCE)
	// @SequenceGenerator(name="accountNumber")
	private long accountNumber;
	private String panNumber;
	@Column(name = "cname", length = 30, nullable = false)
	private String cname;
	@Column(name = "phoneNumber", length = 10)
	private String phoneNumber;

	@Column(name = "adharNumber", length = 12)
	private String adharNumber;

	private double balance;
	private String history = "welcome\n";
	@NotNull
	@Column(name = "password", length = 4)
	private String password;

	public String getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String gethistory() {
		return history;
	}

	public void sethistory(String history) {
		this.history = history + history;
	}

	public double getbalance() {
		return balance;
	}

	public void setbalance(double balance) {
		this.balance = balance;
	}

	public String getpanNumber() {
		return panNumber;
	}

	public void setpanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getphoneNumber() {
		return phoneNumber;
	}

	public void setphoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getadharNumber() {
		return adharNumber;
	}

	public void setadharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}

	public long getaccountNumber() {
		return accountNumber;
	}

	public void setaccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "Customer [account num=" + accountNumber + ", cname=" + cname
				+ ", balanceance=" + balance + "]";

	}
}
