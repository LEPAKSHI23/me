/**
* The class helps listens to the service request
* process with data base
* And report to service
* @author Lepakshi Srinivasan
*/
package com.capgemini.bankapplication.dao;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.capgemini.bankapp.dao.CustomerException;
import com.capgemini.bankapp.dao.PersistenceException;
import com.capgemini.bankapplication.entity.Customer;
import com.capgemini.bankapplication.exception.BankException;

public class CustomerDaoImplementation implements ICustomerDao{
	//private EntityManager entityManager=null;
	//EntityManager entityManager=JPAUtil.getEntityManager();
	Customer temp= new Customer(); 
	static long accountNumber=123456789000000l;
	double balance;
	@PersistenceContext
	private EntityManager entityManager;
	
@Override
	public long addCustomer(Customer c) throws BankException {
	
	try{
	//	System.out.println("hai");
		//entityManager =Persistence.createEntityManagerFactory("BankApplication").createEntityManager();
	  accountNumber=accountNumber+1;
	c.setaccountNumber(accountNumber);

		entityManager.persist(customerEntity);
		return true;
	}catch(PersistenceException e) {
		throw new CustomerException(e.getMessage());
	}	
		return c.getaccountNumber();
	}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}

@Override
	public double showbalance(long accountNumber) throws BankException {
	//EntityManager entityManager=JPAUtil.getEntityManager();	
	EntityManager entityManager=null;
	try{
		entityManager=JPAUtil.getEntityManager();
		temp=entityManager.find(Customer.class,accountNumber);
		return temp.getbalance();
	}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}
	
@Override
 public double withdraw(long accountNumber, double amount)  throws BankException{
	//EntityManager entityManager=JPAUtil.getEntityManager();
		EntityManager entityManager=null;	
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accountNumber);
	double nbalance=temp.getbalance()-amount;
	temp.setbalance(nbalance);
	temp.sethistory("withdrawed ammount is,"+amount);
	entityManager.merge(temp);
	entityManager.getTransaction().commit();
	return temp.getbalance();
}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}
	

@Override
	public double deposit(long accountNumber, double amount) throws BankException {
	//EntityManager entityManager=JPAUtil.getEntityManager();
		EntityManager entityManager=null;	
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accountNumber);
	double nbalance=temp.getbalance()+amount;
	temp.setbalance(nbalance);
	temp.sethistory("deposited ammount is,"+amount);
	entityManager.merge(temp);
	entityManager.getTransaction().commit();
	return temp.getbalance();
		}
		catch(Exception e)
		{throw new BankException(e.getMessage());}
		
	finally
	{entityManager.close();}
	}
	
@Override
	public double fundTransfer(long accountNumber, double amount, long otherAccountNumber)  throws BankException{
    EntityManager entityManager=null;	
	//1EntityManager entityManager=JPAUtil.getEntityManager();
	try{
		entityManager=JPAUtil.getEntityManager();
		//entityManager.getTransaction().begin();
	  /*temp=entityManager.find(Customer.class,accountNumber);
	double nbalance=temp.getbalance()-amount;
	temp.setbalance(nbalance);*/
		withdraw(accountNumber, amount);
	//temp.sethistory("transfered ammount is"+amount);
	temp.sethistory("amount of "+amount+"is transfered to"+otherAccountNumber+" "+LocalDate.now()+LocalTime.now());
	entityManager.merge(temp);
	//temp.sethistory("amount of "+amount+"is transfered to\n");
	//entityManager.getTransaction().commit();
	/*entityManager=JPAUtil.getEntityManager();*/
	//entityManager.getTransaction().begin();
	/*Customer temp1=entityManager.find(Customer.class,tnum);
	double nbalance1=temp1.getbalance()+amount;
	temp1.setbalance(nbalance1);*/
	deposit(otherAccountNumber, amount);
	Customer temp1=new Customer();
	temp1.sethistory("The ammount credited by transfer is ,"+amount);
	entityManager.merge(temp1);
	//entityManager.getTransaction().commit();
	return temp.getbalance();
	}
catch(Exception e)
{throw new BankException(e.getMessage());}

finally
{entityManager.close();}
}
@Override
	public String printTransaction(long accountNumber)  throws BankException{
	 EntityManager entityManager=null;
	 try{
	 entityManager=JPAUtil.getEntityManager();
	 entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accountNumber);
	String s=temp.gethistory();
	entityManager.getTransaction().commit();
		return s;}
	 catch(Exception e)
	 {throw new BankException(e.getMessage());}

	 finally
	 {entityManager.close();}
	 
	 
	}

	public boolean match(long accountNumber, String password) {
		EntityManager entityManager=JPAUtil.getEntityManager();
		boolean flag=false;
		Customer c=entityManager.find(Customer.class,accountNumber);
		if(c!=null)
		{
		if(password.equals(c.getpassword())){
			flag=true;
		}
		else
			return flag;
		}
		return flag;
	}
	public boolean cheakAccount(long accountNumber) {
		EntityManager entityManager=JPAUtil.getEntityManager();
		//try{
		Customer c=entityManager.find(Customer.class,accountNumber);
		if(c==null)
		return false;
		else 
			return true;
		
	}

	/*
	 * public boolean balanceValidation(long acnum) { EntityManager
	 * entityManager=JPAUtil.getEntityManager(); Customer
	 * c=entityManager.find(Customer.class,acnum); boolean f= false;
	 * if(c.getbalance()>=1500) {f=true;} return f; }
	 */
public boolean minbalance(long acnum) {
	EntityManager entityManager=JPAUtil.getEntityManager();
	Customer c=entityManager.find(Customer.class,acnum);
		boolean f= false;
		if (c.getbalance()>1500)
		f=true;
		return f;
	}

public Integer updateCustomer(Customer customerEntity) {
	// TODO Auto-generated method stub
	return null;
}

}
