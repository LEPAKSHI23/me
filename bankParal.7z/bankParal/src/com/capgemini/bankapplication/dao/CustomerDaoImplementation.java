/**
* The class helps listens to the service request
* process with data base
* And report to service
* @author Lepakshi Srinivasan
*/
package com.capgemini.bankapplication.dao;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.stereotype.Repository;

import com.capgemini.bankapplication.entity.CustomerEntity;
import com.capgemini.bankapplication.exception.BankException;
import com.capgemini.bankapplication.model.Customer;

@Repository
public class CustomerDaoImplementation implements ICustomerDao {
	
	
	static long accountNumber = 123456789000000l;
	double balance;
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public long addCustomer(CustomerEntity customerEntity) throws BankException {

		try {
			accountNumber = accountNumber + 1;
			customerEntity.setaccountNumber(accountNumber);
			entityManager.persist(customerEntity);
			return customerEntity.getaccountNumber();

		}
		catch (PersistenceException e)
		{
			throw new BankException(e.getMessage());
		}

		catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}
	}

	@Override
	public double showbalance(long accountNumber) throws BankException {
	
		try {
			
			CustomerEntity temp = entityManager.find(CustomerEntity.class, accountNumber);
			return temp.getbalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}
	}

	@Override
	public double withdraw(long accountNumber, double amount) throws BankException {
		
		try {
			
			CustomerEntity temp = entityManager.find(CustomerEntity.class, accountNumber);
			entityManager.getTransaction().begin();
			double nbalance = temp.getbalance() - amount;
			temp.setbalance(nbalance);
			temp.sethistory("withdrawed ammount is," + amount);
			entityManager.merge(temp);
			entityManager.getTransaction().commit();
			return temp.getbalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}
	}

	@Override
	public double deposit(long accountNumber, double amount) throws BankException {
	
		try {
			
			CustomerEntity	temp = entityManager.find(CustomerEntity.class, accountNumber);
			entityManager.getTransaction().begin();
			double nbalance = temp.getbalance() + amount;
			temp.setbalance(nbalance);
			temp.sethistory("deposited ammount is," + amount);
			entityManager.merge(temp);
			entityManager.getTransaction().commit();
			return temp.getbalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}
	}

	@Override
	public double fundTransfer(long accountNumber, double amount, long otherAccountNumber) throws BankException {
	
		try {
			
			CustomerEntity  temp=entityManager.find(CustomerEntity.class,accountNumber); 
			
		
			entityManager.getTransaction().begin();
			double nbalance=temp.getbalance()-amount;
		temp.setbalance(nbalance);
			 
			temp.sethistory("amount of " + amount + "is transfered to" + otherAccountNumber + " " + LocalDate.now()
					+ LocalTime.now());
			entityManager.merge(temp);
			CustomerEntity temp1=entityManager.find(CustomerEntity.class,otherAccountNumber); double
			  nbalance1=temp1.getbalance()+amount;
			temp1.setbalance(nbalance1);
		temp1.sethistory("The ammount credited by transfer is ," + amount);
			entityManager.merge(temp1);
			 entityManager.getTransaction().commit();
			return temp.getbalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}
	}

	@Override
	public String printTransaction(long accountNumber) throws BankException {
		
		try {
			
			CustomerEntity temp = entityManager.find(CustomerEntity.class, accountNumber);
			String s = temp.gethistory();
			entityManager.getTransaction().commit();
			return s;
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}

		finally {
			entityManager.close();
		}

	}

	public boolean match(long accountNumber, String password) {
		
		boolean flag = false;
		CustomerEntity c = entityManager.find(CustomerEntity.class, accountNumber);
		if (c != null) {
			if (password.equals(c.getpassword())) {
				flag = true;
			} else
				return flag;
		}
		return flag;
	}

	public boolean cheakAccount(long accountNumber) {
		
		CustomerEntity c = entityManager.find(CustomerEntity.class, accountNumber);
		if (c == null)
			return false;
		else
			return true;

	}


	public boolean minbalance(long acnum) {
		
		CustomerEntity c = entityManager.find(CustomerEntity.class, acnum);
		boolean f = false;
		if (c.getbalance() > 1500)
			f = true;
		return f;
	}

	public Integer updateCustomer(Customer customerEntity) {
		// TODO Auto-generated method stub
		return null;
	}

}
