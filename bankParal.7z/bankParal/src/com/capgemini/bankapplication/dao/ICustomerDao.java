/**
* The  interface helps listens to the service request
* And implemented in the class CustomerDaoImplementation 

* @author Lepakshi Srinivasan
*/
package com.capgemini.bankapplication.dao;

import com.capgemini.bankapplication.entity.Customer;
import com.capgemini.bankapplication.exception.BankException;

public interface ICustomerDao {
	public long addCustomer(Customer c) throws BankException;

	public double showbalance(long accountNumber) throws BankException;

	public String printTransaction(long accountNumber) throws BankException;

	public double withdraw(long accountNumber, double amount) throws BankException;

	public double deposit(long accountNumber, double amount) throws BankException;

	public double fundTransfer(long accountNumber, double amount, long otherAccountNumber) throws BankException;

}
