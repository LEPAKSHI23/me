package com.capgemini.bankapplication.exception;

public class BankException {
	private static final long serialVersionUID = 1L;
	private String status;
	
	public BankException() {
		this.status="Unable to perform operation";
	}
	
	public BankException(String status) {
		
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "CustomerException [status=" + status + "]";
	}
}
