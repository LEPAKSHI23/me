package com.capgemini.bankapplication.service;

import com.capgemini.bankapplication.entity.Customer;
import com.capgemini.bankapplication.exception.BankException;

public interface ICustomerService {
	public long addCustomer(com.capgemini.bankapplication.bean.Customer customer)  throws BankException;

	public double showbalance(long accountNumber)  throws BankException;

	public String printTransaction(long accountNumber)  throws BankException;

	public double withdraw(long accountNumber, double amount)  throws BankException;

	public double deposit(long accountNumber, double amount) throws BankException;

	public double fundTransfer(long accountNumber, double amount, long tnum)  throws BankException;

	Integer updateCustomer(Customer customer) throws BankException;

}
