package com.capgemini.bankapplication.service;

import com.capgemini.bankapplication.entity.CustomerEntity;
import com.capgemini.bankapplication.exception.BankException;
import com.capgemini.bankapplication.model.Customer;

public interface ICustomerService {
	public long addCustomer(CustomerEntity customer)  throws BankException;

	public double showbalance(long accountNumber)  throws BankException;

	public String printTransaction(long accountNumber)  throws BankException;

	public double withdraw(long accountNumber, double amount)  throws BankException;

	public double deposit(long accountNumber, double amount) throws BankException;

	public double fundTransfer(long accountNumber, double amount, long tnum)  throws BankException;

	Integer updateCustomer(Customer customer) throws BankException;

}
