package com.capgemini.bankapplication.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bankapplication.exception.BankException;
import com.capgemini.bankapplication.model.Customer;

public class CustomerValidator {

	//returns true if name contains first letter as Upper case alphabet and allows alphabets and spaces only

	public boolean validateName(String name)throws BankException
	{

		Pattern Name=Pattern.compile("[A-Z][a-z\\sA-Z]+");
		Matcher Namematch=Name.matcher(name);
		if(Namematch.matches()&&name.length()>2) 
			return true;
		else
			return false;
	}

	//returns true if the age is between 10 to 80
	public boolean validateAge(int age)throws BankException
	{
		if(age>10&&age<80)
			return true;
		else
			return false;
	}
	// returns true when the mobile number consists of 10 digits and the first number must be between 6 to 9
	public boolean validatePhnno(String phnno)throws CustomerException
	{
		Pattern Mob=Pattern.compile("[6-9][0-9]{9}");
		Matcher Mobmatch=Mob.matcher(phnno);
		if(Mobmatch.matches()) 
			return true;
		else
			return false;
	}
	// returns true if the address contains door number, street with alphabets
	public boolean validateAddress(String address)throws CustomerException
	{
		Pattern Addr=Pattern.compile("^[0-9][A-Za-z0-9\\s,.#-]*");
		Matcher Addrmatch=Addr.matcher(address);
		if(Addrmatch.matches()&&address.length()>3) 
			return true;
		else
			return false;
	}


	// returns true if there are 12 digits
	public boolean validateAadharno(String aadharno)throws CustomerException
	{

		Pattern aadhar=Pattern.compile("[0-9]{12}");
		Matcher aadharmatch=aadhar.matcher(aadharno);
		if(aadharmatch.matches())
			return true;
		else
			return false;
	}

	public boolean validate(Customer customer) throws CustomerException
	{
		if(!this.validateName(customer.getName()))
		{
			System.err.println("\n Enter the NAME correctly(eg:Nivedha");
		}else if(!this.validateAge(customer.getAge()))
		{
			System.err.println("\n Invalid age");
		}else if(!this.validatePhnno(customer.getPhnno()))
		{
			System.err.println("\n Enter the MOBILE NUMBER correctly(eg:7418670635)");
		}else if(!this.validateAddress(customer.getAddress()))
		{
			System.err.println("\n Enter the ADDRESS correctly(eg:27,Gandhi road)");
		}else if(!this.validateAadharno(customer.getAadharno()))
		{
			System.err.println("\n Enter the AADHAR NUMBER correctly(eg:875421457896)");
		}else

		{
			return true;
		}
		return false;	
	}
}

