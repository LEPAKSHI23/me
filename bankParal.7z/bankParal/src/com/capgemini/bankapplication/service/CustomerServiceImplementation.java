package com.capgemini.bankapplication.service;

import com.capgemini.bankapplication.dao.CustomerDaoImplementation;
import com.capgemini.bankapplication.entity.Customer;
import com.capgemini.bankapplication.entity.CustomerEntity;
import com.capgemini.bankapplication.exception.BankException;

public class CustomerServiceImplementation implements ICustomerService {
	Customer c = new Customer();
	CustomerDaoImplementation dao = new CustomerDaoImplementation();

	@Override
	public long addCustomer(Customer c) throws BankException {

		return dao.addCustomer(c);
	}

	@Override
	public double showbalance(long accountNumber) throws BankException {
		return dao.showbalance(accountNumber);
	}

	@Override
	public double withdraw(long accountNumber, double amount)
			throws BankException {

		return dao.withdraw(accountNumber, amount);
	}

	@Override
	public double deposit(long accountNumber, double amount)
			throws BankException {
		return dao.deposit(accountNumber, amount);

	}

	@Override
	public double fundTransfer(long accountNumber, double amount, long tnum)
			throws BankException {

		return dao.fundTransfer(accountNumber, amount, tnum);
	}

	@Override
	public String printTransaction(long accountNumber) throws BankException {
		return dao.printTransaction(accountNumber);
	}

	public boolean nameValidation(String cname) {
		boolean f = false;
		if (cname.matches("^[A-Za-z\\s]+$"))
			f = true;
		return f;
	}

	public boolean panValidation(String panNumber) {
		boolean f = false;
		if (panNumber.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}"))
			f = true;
		return f;
	}

	/*
	 * public boolean dob(String dob) { boolean f= false; if
	 * (dob.matches("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$"))
	 * f=true; return f; }
	 */

	public boolean phoneNumberValidation(String phoneNumber) {

		boolean f = false;
		if (phoneNumber.matches("[6-9]{1}[0-9]{9}"))
			f = true;
		return f;
	}

	public boolean adharValidation(String adhar) {

		boolean f = false;
		if (adhar.matches("[1-9][\\d{3}\\s\\d{4}\\s\\d{4}$],\\s")
				|| (adhar.matches("[1-9][0-9]{11}")))
			f = true;
		return f;
	}

	public boolean validateAccount(long accountNumber) {

		boolean f = false;
		String s = Long.toString(accountNumber);
		if (s.matches("[0-9]{15}")) {
			f = true;
		}
		return f;

	}

	public boolean validatepassword(String password)

	{
		boolean f = false;

		if (password.matches("[0-9]{4}")) {
			f = true;
		}
		return f;

	}

	/*
	 * public boolean balanceValidation(long acnum) {
	 * 
	 * 
	 * return dao.balanceValidation(acnum); }
	 */
	public boolean minbalance(long acnum) {

		return dao.minbalance(acnum);
	}

	public boolean match(long accountNumber, String password) {

		return dao.match(accountNumber, password);

	}

	public boolean cheakAccount(long accountNumber) {
		return dao.cheakAccount(accountNumber);
	}
	@Override
	public Integer updateCustomer(Customer customer) throws BankException {
		Customer customerEntity=new Customer();
		populateCustomerEntity(customer,customerEntity);
		return dao.updateCustomer(customerEntity);
	}
	private void populateCustomerEntity(Customer customer, Customer customer) {
		customer.setaccountNumber(customer.getaccountNumber());
		customer.setCname(customer.getCname());
		customer.setphoneNumber(customer.getphoneNumber());
	customer.setadharNumber(customer.getadharNumber());
		customer.setpanNumber(customer.getpanNumber());
	}
	
}
